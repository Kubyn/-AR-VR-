import React from 'react';
import { Laptop, Smartphone, Cpu, Headphones, Radio, HardDrive } from 'lucide-react';

interface RequirementProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const RequirementItem: React.FC<RequirementProps> = ({ icon, title, description }) => {
  return (
    <div className="flex items-start">
      <div className="flex-shrink-0 mt-1">
        <div className="p-2 bg-blue-100 rounded-lg">
          {icon}
        </div>
      </div>
      <div className="ml-4">
        <h4 className="text-lg font-semibold text-gray-900 mb-1">{title}</h4>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
};

const TechInfo: React.FC = () => {
  const requirements = [
    {
      icon: <Laptop className="w-5 h-5 text-blue-700" />,
      title: "Computer Requirements",
      description: "Windows 10/11, macOS 10.15+, or Chrome OS with Intel i5/AMD Ryzen 5 (or newer) processor."
    },
    {
      icon: <Smartphone className="w-5 h-5 text-blue-700" />,
      title: "Mobile Devices",
      description: "iOS 14+ or Android 10+ for companion apps and certain VR experiences."
    },
    {
      icon: <Cpu className="w-5 h-5 text-blue-700" />,
      title: "Processing Power",
      description: "8GB RAM minimum, 16GB recommended for optimal performance."
    },
    {
      icon: <HardDrive className="w-5 h-5 text-blue-700" />,
      title: "Storage Space",
      description: "10-50GB free space depending on the VR programs being utilized."
    },
    {
      icon: <Radio className="w-5 h-5 text-blue-700" />,
      title: "Internet Connection",
      description: "Broadband connection with at least 25Mbps download speed."
    },
    {
      icon: <Headphones className="w-5 h-5 text-blue-700" />,
      title: "Audio Equipment",
      description: "Built-in speakers or headphones for immersive 3D audio experience."
    }
  ];

  return (
    <section id="tech-info" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">Technical Information</h2>
            <p className="text-xl text-gray-600">
              Get familiar with the hardware and software requirements needed to implement VR in your educational environment.
            </p>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h3 className="text-2xl font-bold mb-6 text-gray-900">System Requirements</h3>
            
            <div className="grid gap-8 md:grid-cols-2">
              {requirements.map((req, index) => (
                <RequirementItem 
                  key={index}
                  icon={req.icon}
                  title={req.title}
                  description={req.description}
                />
              ))}
            </div>
            
            <div className="mt-10 border-t border-gray-200 pt-8">
              <h3 className="text-2xl font-bold mb-4 text-gray-900">VR Hardware Options</h3>
              <p className="text-gray-700 mb-6">
                Depending on your budget and needs, there are several VR hardware options available:
              </p>
              
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>
                  <span className="font-medium">Entry Level:</span> Google Cardboard, smartphone-based VR viewers
                </li>
                <li>
                  <span className="font-medium">Mid-Range:</span> Meta Quest 2/3, Pico Neo 3, standalone headsets
                </li>
                <li>
                  <span className="font-medium">High-End:</span> Valve Index, HTC Vive Pro, PC-connected headsets
                </li>
                <li>
                  <span className="font-medium">Classroom Sets:</span> Multi-user packages available from most manufacturers
                </li>
              </ul>
              
              <div className="mt-8">
                <button className="px-6 py-3 bg-blue-700 hover:bg-blue-800 text-white rounded-md font-medium transition-colors duration-200">
                  Download Full Requirements PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TechInfo;