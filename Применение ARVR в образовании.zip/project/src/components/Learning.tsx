import React from 'react';
import { CheckCircle } from 'lucide-react';

const Learning: React.FC = () => {
  const benefits = [
    "Increased student engagement and retention of information",
    "Safe experimentation in otherwise dangerous environments",
    "Access to places and experiences typically inaccessible in traditional education",
    "Development of spatial awareness and 3D understanding",
    "Personalized learning pathways adapted to individual progress",
    "Reduced costs compared to specialized physical equipment",
  ];

  return (
    <section id="learning" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="w-full lg:w-1/2">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
              Learning Through Virtual Reality
            </h2>
            <p className="text-lg text-gray-700 mb-8">
              Virtual Reality offers unprecedented opportunities for immersive learning experiences 
              that engage multiple senses, making abstract concepts tangible and complex subjects 
              more accessible to students of all learning styles.
            </p>
            
            <div className="mb-10">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start mb-4">
                  <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                  <p className="ml-3 text-gray-700">{benefit}</p>
                </div>
              ))}
            </div>
            
            <button className="px-8 py-3 bg-blue-700 hover:bg-blue-800 text-white rounded-md font-medium transition-colors duration-200">
              Explore Learning Methods
            </button>
          </div>
          
          <div className="w-full lg:w-1/2 rounded-lg overflow-hidden shadow-xl">
            <div className="relative pb-[56.25%]"> {/* 16:9 aspect ratio */}
              <img 
                src="https://images.pexels.com/photos/8721342/pexels-photo-8721342.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                alt="Students learning with VR headsets" 
                className="absolute inset-0 w-full h-full object-cover rounded-lg"
              />
              
              {/* Overlay with play button for video feel */}
              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-20 hover:bg-opacity-30 transition-opacity duration-300 cursor-pointer rounded-lg">
                <div className="w-16 h-16 md:w-20 md:h-20 bg-white rounded-full flex items-center justify-center">
                  <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-blue-700 border-b-[10px] border-b-transparent ml-1"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Learning;