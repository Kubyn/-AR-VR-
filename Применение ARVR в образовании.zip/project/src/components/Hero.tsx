import React from 'react';
import { ChevronDown } from 'lucide-react';
import { useLanguageStore } from '../store/languageStore';
import { translations } from '../translations';

const Hero: React.FC = () => {
  const { language } = useLanguageStore();
  const t = translations[language];

  const scrollToNext = () => {
    const programsSection = document.getElementById('programs');
    if (programsSection) {
      programsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 text-white overflow-hidden"
    >
      {/* Abstract shapes */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-20 -right-20 w-96 h-96 bg-purple-600 opacity-20 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 -left-20 w-72 h-72 bg-blue-400 opacity-20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-20 right-1/3 w-80 h-80 bg-indigo-500 opacity-10 rounded-full blur-3xl"></div>
      </div>

      {/* Floating objects */}
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 border border-white/20 rounded-lg rotate-12 animate-float-slow"></div>
        <div className="absolute top-1/3 right-1/4 w-24 h-24 border border-white/20 rounded-full -rotate-12 animate-float-medium"></div>
        <div className="absolute bottom-1/3 left-1/3 w-40 h-40 border border-white/20 rounded-lg rotate-45 animate-float-fast"></div>
      </div>

      <div className="container mx-auto px-4 pt-20 z-10 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
          {t.heroTitle}
        </h1>
        <p className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto text-gray-200">
          {t.heroSubtitle}
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-16">
          <button className="px-8 py-3 bg-purple-600 hover:bg-purple-700 rounded-md font-medium transition-colors duration-200">
            {t.explorePrograms}
          </button>
          <button className="px-8 py-3 bg-transparent hover:bg-white/10 border border-white rounded-md font-medium transition-colors duration-200">
            {t.learnMore}
          </button>
        </div>

        <div className="mt-16 animate-bounce">
          <button
            onClick={scrollToNext}
            className="flex items-center justify-center w-10 h-10 mx-auto rounded-full border border-white/30 hover:border-white/60 transition-colors duration-200"
            aria-label="Scroll down"
          >
            <ChevronDown className="w-6 h-6" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;