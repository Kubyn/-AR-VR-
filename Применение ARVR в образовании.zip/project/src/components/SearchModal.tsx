import React, { useState, useEffect } from 'react';
import { Search, X, ExternalLink } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface VideoResult {
  id: string;
  title: string;
  thumbnail: string;
  channelTitle: string;
}

// Predefined list of VR education videos
const predefinedVideos: VideoResult[] = [
  {
    id: "6AOpomu9V6Q",
    title: "VR for Education - What's the Reality?",
    thumbnail: "https://i3.ytimg.com/vi/6AOpomu9V6Q/mqdefault.jpg",
    channelTitle: "TEDx Talks"
  },
  {
    id: "wJkix9VAPbg",
    title: "How Virtual Reality Can Transform Education",
    thumbnail: "https://i3.ytimg.com/vi/wJkix9VAPbg/mqdefault.jpg",
    channelTitle: "Educational Technology"
  },
  {
    id: "EXYzj6qwCCk",
    title: "Virtual Reality in Education: The Future of Learning",
    thumbnail: "https://i3.ytimg.com/vi/EXYzj6qwCCk/mqdefault.jpg",
    channelTitle: "VR Education"
  },
  {
    id: "B4g_GwJjCwY",
    title: "Using VR in the Classroom: Practical Applications",
    thumbnail: "https://i3.ytimg.com/vi/B4g_GwJjCwY/mqdefault.jpg",
    channelTitle: "Teaching with Tech"
  },
  {
    id: "3LQ5DGxM1yY",
    title: "Virtual Reality for Science Education",
    thumbnail: "https://i3.ytimg.com/vi/3LQ5DGxM1yY/mqdefault.jpg",
    channelTitle: "Science VR"
  }
];

const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<VideoResult[]>([]);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setResults([]);
      return;
    }

    const searchTerms = searchQuery.toLowerCase().split(' ');
    const filteredVideos = predefinedVideos.filter(video => 
      searchTerms.every(term => 
        video.title.toLowerCase().includes(term) || 
        video.channelTitle.toLowerCase().includes(term)
      )
    );
    setResults(filteredVideos);
  }, [searchQuery]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-start justify-center pt-20">
      <div className="bg-white w-full max-w-3xl rounded-xl shadow-2xl mx-4">
        <div className="p-4 border-b border-gray-200 flex items-center">
          <Search className="w-5 h-5 text-gray-400 mr-3" />
          <input
            type="text"
            placeholder="Search VR educational videos..."
            className="flex-1 text-lg outline-none"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoFocus
          />
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="max-h-[70vh] overflow-y-auto">
          {results.length > 0 ? (
            <div className="grid gap-4 p-4">
              {results.map((video) => (
                <div
                  key={video.id}
                  className="flex gap-4 p-3 hover:bg-gray-50 rounded-lg transition-colors duration-200 cursor-pointer group"
                  onClick={() => window.open(`https://youtube.com/watch?v=${video.id}`, '_blank')}
                >
                  <div className="w-48 h-27 rounded-lg overflow-hidden flex-shrink-0 relative">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity duration-200"></div>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 flex items-center gap-2">
                      {video.title}
                      <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">{video.channelTitle}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : searchQuery ? (
            <div className="p-8 text-center text-gray-500">
              No videos found for "{searchQuery}"
            </div>
          ) : (
            <div className="p-8 text-center text-gray-500">
              Start typing to search for VR educational videos
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SearchModal;