import React from 'react';
import { Lightbulb, BrainCircuit, Microscope, School, HeartPulse, Globe } from 'lucide-react';

interface ProgramCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: string;
}

const ProgramCard: React.FC<ProgramCardProps> = ({ icon, title, description, color }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className={`w-14 h-14 ${color} rounded-lg flex items-center justify-center mb-4`}>
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-2 text-gray-800">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const Programs: React.FC = () => {
  const programs = [
    {
      icon: <Lightbulb className="w-7 h-7 text-white" />,
      title: "Interactive Physics Labs",
      description: "Engage with complex physics concepts through immersive virtual experiments.",
      color: "bg-blue-600"
    },
    {
      icon: <BrainCircuit className="w-7 h-7 text-white" />,
      title: "Neural Network Visualization",
      description: "Travel inside AI systems and learn how machine learning works from within.",
      color: "bg-purple-600"
    },
    {
      icon: <Microscope className="w-7 h-7 text-white" />,
      title: "Biology Explorer",
      description: "Journey through cellular structures and biological systems at microscopic scale.",
      color: "bg-green-600"
    },
    {
      icon: <School className="w-7 h-7 text-white" />,
      title: "Historical Reconstructions",
      description: "Visit accurate recreations of ancient civilizations and historical events.",
      color: "bg-amber-600"
    },
    {
      icon: <HeartPulse className="w-7 h-7 text-white" />,
      title: "Medical Training",
      description: "Practice surgical procedures and anatomy studies in risk-free environments.",
      color: "bg-red-600"
    },
    {
      icon: <Globe className="w-7 h-7 text-white" />,
      title: "Geography Expeditions",
      description: "Explore remote locations and natural wonders without leaving the classroom.",
      color: "bg-teal-600"
    }
  ];

  return (
    <section id="programs" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
            Popular VR Educational Programs
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the most effective virtual reality applications that are transforming traditional learning experiences.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {programs.map((program, index) => (
            <ProgramCard
              key={index}
              icon={program.icon}
              title={program.title}
              description={program.description}
              color={program.color}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Programs;