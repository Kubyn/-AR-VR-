import React, { useState, useEffect } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import SearchModal from './SearchModal';
import { useLanguageStore } from '../store/languageStore';
import { translations } from '../translations';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);
  const { language, setLanguage } = useLanguageStore();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { key: 'home', label: translations[language].home },
    { key: 'programs', label: translations[language].programs },
    { key: 'learning', label: translations[language].learning },
    { key: 'testimonials', label: translations[language].testimonials },
    { key: 'techInfo', label: translations[language].techInfo },
  ];

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'ru', name: 'Русский' },
    { code: 'kk', name: 'Қазақша' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
        }`}
      >
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center">
            <span className={`text-2xl font-bold ${isScrolled ? 'text-blue-800' : 'text-white'}`}>
              VR<span className="text-purple-600">Edu</span>
            </span>
          </div>

          {/* Desktop Menu */}
          <nav className="hidden md:flex space-x-8 items-center">
            {menuItems.map((item) => (
              <a
                key={item.key}
                href={`#${item.key}`}
                className={`font-medium transition-colors duration-200 ${
                  isScrolled ? 'text-gray-700 hover:text-blue-800' : 'text-white hover:text-purple-300'
                }`}
              >
                {item.label}
              </a>
            ))}
            
            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => setIsLanguageOpen(!isLanguageOpen)}
                className={`p-2 rounded-full transition-colors duration-200 flex items-center gap-2 ${
                  isScrolled ? 'hover:bg-gray-100' : 'hover:bg-white/10'
                }`}
              >
                <Globe className={isScrolled ? 'text-gray-700' : 'text-white'} size={20} />
              </button>
              
              {isLanguageOpen && (
                <div className="absolute right-0 mt-2 py-2 w-48 bg-white rounded-lg shadow-xl">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code as 'en' | 'ru' | 'kk');
                        setIsLanguageOpen(false);
                      }}
                      className={`w-full text-left px-4 py-2 hover:bg-gray-100 ${
                        language === lang.code ? 'text-purple-600' : 'text-gray-700'
                      }`}
                    >
                      {lang.name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2 rounded-md transition-colors duration-200"
              onClick={() => setIsSearchOpen(true)}
            >
              {translations[language].getStarted}
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden z-50"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <X className={`h-6 w-6 ${isScrolled ? 'text-gray-800' : 'text-white'}`} />
            ) : (
              <Menu className={`h-6 w-6 ${isScrolled ? 'text-gray-800' : 'text-white'}`} />
            )}
          </button>

          {/* Mobile Menu */}
          <div
            className={`fixed inset-0 bg-blue-900 bg-opacity-95 flex flex-col items-center justify-center space-y-8 transition-opacity duration-300 ${
              isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
            }`}
          >
            {menuItems.map((item) => (
              <a
                key={item.key}
                href={`#${item.key}`}
                className="text-white text-xl font-medium hover:text-purple-300 transition-colors duration-200"
                onClick={() => setIsMenuOpen(false)}
              >
                {item.label}
              </a>
            ))}

            {/* Mobile Language Selector */}
            <div className="flex flex-col items-center gap-4">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    setLanguage(lang.code as 'en' | 'ru' | 'kk');
                    setIsMenuOpen(false);
                  }}
                  className={`text-xl ${
                    language === lang.code ? 'text-purple-300' : 'text-white'
                  } hover:text-purple-300 transition-colors duration-200`}
                >
                  {lang.name}
                </button>
              ))}
            </div>

            <button
              className="mt-4 bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-md transition-colors duration-200"
              onClick={() => {
                setIsMenuOpen(false);
                setIsSearchOpen(true);
              }}
            >
              {translations[language].getStarted}
            </button>
          </div>
        </div>
      </header>

      <SearchModal 
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />
    </>
  );
};

export default Header;