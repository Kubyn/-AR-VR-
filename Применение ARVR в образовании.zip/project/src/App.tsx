import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Programs from './components/Programs';
import Learning from './components/Learning';
import Testimonials from './components/Testimonials';
import TechInfo from './components/TechInfo';
import Footer from './components/Footer';
import './utils/animations.css';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <Programs />
      <Learning />
      <Testimonials />
      <TechInfo />
      <Footer />
    </div>
  );
}

export default App;