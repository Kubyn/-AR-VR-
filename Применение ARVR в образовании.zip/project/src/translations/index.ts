interface Translations {
  getStarted: string;
  search: string;
  home: string;
  programs: string;
  learning: string;
  testimonials: string;
  techInfo: string;
  heroTitle: string;
  heroSubtitle: string;
  explorePrograms: string;
  learnMore: string;
  popularPrograms: string;
  popularProgramsSubtitle: string;
  learningTitle: string;
  learningDescription: string;
  exploreLearningMethods: string;
  successStories: string;
  successStoriesSubtitle: string;
  technicalInformation: string;
  technicalInformationSubtitle: string;
  systemRequirements: string;
  vrHardwareOptions: string;
  vrHardwareDescription: string;
  downloadRequirements: string;
  footerAbout: string;
  subscribeNewsletter: string;
  subscribeButton: string;
  emailPlaceholder: string;
  allRightsReserved: string;
}

export const translations: Record<string, Translations> = {
  en: {
    getStarted: 'Get Started',
    search: 'Search',
    home: 'Home',
    programs: 'Programs',
    learning: 'Learning',
    testimonials: 'Testimonials',
    techInfo: 'Tech Info',
    heroTitle: 'Transform Education with Virtual Reality',
    heroSubtitle: 'Discover how VR technology is revolutionizing learning experiences and opening new horizons in education.',
    explorePrograms: 'Explore Programs',
    learnMore: 'Learn More',
    popularPrograms: 'Popular VR Educational Programs',
    popularProgramsSubtitle: 'Discover the most effective virtual reality applications that are transforming traditional learning experiences.',
    learningTitle: 'Learning Through Virtual Reality',
    learningDescription: 'Virtual Reality offers unprecedented opportunities for immersive learning experiences that engage multiple senses, making abstract concepts tangible and complex subjects more accessible to students of all learning styles.',
    exploreLearningMethods: 'Explore Learning Methods',
    successStories: 'Success Stories',
    successStoriesSubtitle: 'Hear from educators who have transformed their teaching with VR technology.',
    technicalInformation: 'Technical Information',
    technicalInformationSubtitle: 'Get familiar with the hardware and software requirements needed to implement VR in your educational environment.',
    systemRequirements: 'System Requirements',
    vrHardwareOptions: 'VR Hardware Options',
    vrHardwareDescription: 'Depending on your budget and needs, there are several VR hardware options available:',
    downloadRequirements: 'Download Full Requirements PDF',
    footerAbout: 'Transforming education through immersive virtual reality experiences.',
    subscribeNewsletter: 'Subscribe to our newsletter for the latest VR education news and resources.',
    subscribeButton: 'Subscribe',
    emailPlaceholder: 'Your email address',
    allRightsReserved: '© 2025 VREdu. All rights reserved.'
  },
  ru: {
    getStarted: 'Начать',
    search: 'Поиск',
    home: 'Главная',
    programs: 'Программы',
    learning: 'Обучение',
    testimonials: 'Отзывы',
    techInfo: 'Технологии',
    heroTitle: 'Трансформация образования с помощью виртуальной реальности',
    heroSubtitle: 'Узнайте, как технология виртуальной реальности революционизирует процесс обучения и открывает новые горизонты в образовании.',
    explorePrograms: 'Изучить программы',
    learnMore: 'Узнать больше',
    popularPrograms: 'Популярные образовательные программы VR',
    popularProgramsSubtitle: 'Откройте для себя самые эффективные приложения виртуальной реальности, которые трансформируют традиционный опыт обучения.',
    learningTitle: 'Обучение через виртуальную реальность',
    learningDescription: 'Виртуальная реальность предоставляет беспрецедентные возможности для иммерсивного обучения, которое задействует множество органов чувств, делая абстрактные концепции осязаемыми, а сложные предметы более доступными для учащихся с разными стилями обучения.',
    exploreLearningMethods: 'Изучить методы обучения',
    successStories: 'Истории успеха',
    successStoriesSubtitle: 'Узнайте от преподавателей, как они трансформировали свое преподавание с помощью технологии VR.',
    technicalInformation: 'Техническая информация',
    technicalInformationSubtitle: 'Ознакомьтесь с требованиями к оборудованию и программному обеспечению, необходимыми для внедрения VR в образовательную среду.',
    systemRequirements: 'Системные требования',
    vrHardwareOptions: 'Варианты VR оборудования',
    vrHardwareDescription: 'В зависимости от вашего бюджета и потребностей, доступны различные варианты VR оборудования:',
    downloadRequirements: 'Скачать полные требования PDF',
    footerAbout: 'Трансформация образования через иммерсивный опыт виртуальной реальности.',
    subscribeNewsletter: 'Подпишитесь на нашу рассылку для получения последних новостей и ресурсов VR образования.',
    subscribeButton: 'Подписаться',
    emailPlaceholder: 'Ваш email адрес',
    allRightsReserved: '© 2025 VREdu. Все права защищены.'
  },
  kk: {
    getStarted: 'Бастау',
    search: 'Іздеу',
    home: 'Басты бет',
    programs: 'Бағдарламалар',
    learning: 'Оқыту',
    testimonials: 'Пікірлер',
    techInfo: 'Технология',
    heroTitle: 'Виртуалды шындық арқылы білім беруді өзгерту',
    heroSubtitle: 'Виртуалды шындық технологиясы оқыту тәжірибесін қалай өзгертіп, білім берудегі жаңа көкжиектерді ашып жатқанын біліңіз.',
    explorePrograms: 'Бағдарламаларды зерттеу',
    learnMore: 'Көбірек білу',
    popularPrograms: 'Танымал VR білім беру бағдарламалары',
    popularProgramsSubtitle: 'Дәстүрлі оқыту тәжірибесін өзгертетін ең тиімді виртуалды шындық қосымшаларын ашыңыз.',
    learningTitle: 'Виртуалды шындық арқылы оқыту',
    learningDescription: 'Виртуалды шындық көптеген сезім мүшелерін қамтитын иммерсивті оқыту мүмкіндіктерін ұсынады, абстрактілі ұғымдарды нақты етіп, күрделі пәндерді барлық оқу стильдеріндегі студенттерге қолжетімді етеді.',
    exploreLearningMethods: 'Оқыту әдістерін зерттеу',
    successStories: 'Табыс тарихтары',
    successStoriesSubtitle: 'VR технологиясы арқылы өз оқытуларын қалай өзгерткені туралы оқытушылардан біліңіз.',
    technicalInformation: 'Техникалық ақпарат',
    technicalInformationSubtitle: 'Білім беру ортасында VR енгізу үшін қажетті жабдық және бағдарламалық жасақтама талаптарымен танысыңыз.',
    systemRequirements: 'Жүйе талаптары',
    vrHardwareOptions: 'VR жабдық нұсқалары',
    vrHardwareDescription: 'Бюджет пен қажеттіліктеріңізге байланысты бірнеше VR жабдық нұсқалары қолжетімді:',
    downloadRequirements: 'Толық талаптарды PDF жүктеу',
    footerAbout: 'Иммерсивті виртуалды шындық тәжірибесі арқылы білім беруді өзгерту.',
    subscribeNewsletter: 'VR білім беру жаңалықтары мен ресурстары туралы соңғы ақпарат алу үшін жазылыңыз.',
    subscribeButton: 'Жазылу',
    emailPlaceholder: 'Сіздің email мекенжайыңыз',
    allRightsReserved: '© 2025 VREdu. Барлық құқықтар қорғалған.'
  }
};